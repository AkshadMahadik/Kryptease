function handleFileSelect(evt){
var files = evt.target.files; // FileList object
  var file = files[0];
  var reader = new FileReader();
  reader.onload = function() {
    // contents of file
    var contents = this.result;
    // name of file
    var filename = file.name;
    // do something with contents and filename
  };
  reader.readAsText(file);
}
document.getElementById('file').addEventListener('change', handleFileSelect, false);
var js_string = file;
var python_code = "def my_function(js_string):\n    print('Message from JavaScript:', js_string)\n";
var py = require('js2py');
py.eval_js(python_code);
py.my_function(js_string);
from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.contrib.auth import login,authenticate,logout
from django.core.files import File as Filee
from django.contrib import messages
from django.contrib.auth.decorators import *
from .models import *
from .cryptor import *

# 
key = b'[EX\xc8\xd5\xbfI{\xa2$\x05(\xd5\x18\xbf\xc0\x85)\x10nc\x94\x02)j\xdf\xcb\xc4\x94\x9d(\x9e'
def pad(s):
        return s + b"\0" * (AES.block_size - len(s) % AES.block_size)
def encrypt( message, key, key_size=256):
        message = pad(message)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        return iv + cipher.encrypt(message)


def decrypt(ciphertext, key):
        iv = ciphertext[:AES.block_size]
        cipher = AES.new(key, AES.MODE_CBC, iv)
        plaintext = cipher.decrypt(ciphertext[AES.block_size:])
        return plaintext.rstrip(b"\0")


# ##########

def home(request):
    return render(request,'home.html',{})

def registeruser(request):
    if request.method=='GET':
        return render(request,'registeruser.html',{})
    else:
        uname=request.POST['username']
        em=request.POST['email']
        pass1=request.POST['password1']
        pass2=request.POST['password2']
        print(uname)
        print(pass1)
        print(pass2)
        print(em)
     

        if pass1==pass2:
            try:
                user=User.objects.create_user(username=uname,password=pass1,email=em)
                user.save()
                u=authenticate(request,username=uname,password=pass1)
                login(request,u)
                messages.success(request,'registeration successfull')
                return redirect('home')
            except:
                messages.error(request,'username already taken !! try new one')
                return render(request,'register.html',{})
            
        else:
            messages.error(request,'passwords didnt matched')
            return render(request,'register.html',{})
        

def login_user(request):
    if request.method=='GET':
        return render(request,'login.html')
    else:
        username=request.POST['username']
        password=request.POST['password']
        # to authenticate the user
        user=authenticate(request,username=username,password=password)
        # if the user is authenticated it wont refer none
        if user is not None:
            login(request,user)
            messages.success(request,'you have successfully logged in')
            return redirect('home')
        else:
            messages.error(request,'YOUR PASSWORD AND USERNAME DIDNT MATCHED   ENTER AGAIN')
            return render(request,'login.html',context={})
        
def logout_user(request):
    logout(request)
    messages.warning(request,'you have logged out')
    return redirect('home')
    
@login_required(login_url='login')
def encryptview(request):
    if request.method=='GET':
        return render(request,'encrypt.html',{})
    else:
        try:
            f=request.FILES["upload"]
            fname=f.name
            print(fname)
            file=File.objects.create(user=request.user,filename=fname,userfile=f)
            file.save()
            with open(f'media/files/{fname}','rb') as fo:
                plaintext=fo.read()
            enc=encrypt(plaintext,key)
            print(enc)
            nfname=fname.replace('.txt','')
            fo=Filee(open(f'{nfname}.enc','wb'))
            fo.write(enc)
            fo.close()
            # with File(open(f'media/thrash/{nfname}.enc','wb')) as fo:
            #      fo.write(enc)
            # e=Encfile.objects.create(mainfile=file,encfilename=f'{fname}.enc',encfile=fo)
            # e.save()
            e=Encfile()
            e.mainfile=file
            e.encfilename=f'{nfname}.enc'
            foo=Filee(open(f'{nfname}.enc','rb'))
            e.encfile=foo
            e.user=request.user
            e.save()
            foo.close()
            os.remove(f'{nfname}.enc')
            messages.success(request,'FILE ENCRYPTED SUCCESSFULLY :)')
            return redirect('allenc')
        except:
            messages.error(request,'ERROR WHILE ENCRYPTING FILE ')
            return render(request,'home.html')

@login_required(login_url='login')
def decryptview(request):
    if request.method=='GET':
        return render(request,'decrypt.html',{})
    else:
        try:
            f=request.FILES["upload"]
            fname=f.name
            # if fname[-1:-5]!='.enc':
            #     print("bad data")
            #     print(fname[-1:-5])
            # return render(request,'decrypt.html',{})
            file=File.objects.create(user=request.user,filename=fname,userfile=f)
            file.save()
            fo=Filee(open(f'media/files/{fname}','rb'))
            ciphertext=fo.read()
            fo.close()
            dec = decrypt(ciphertext,key)
            fo=Filee(open(f'{fname[:-4]}.txt','wb'))
            fo.write(dec)
            fo.close()
            d=Decrfile()
            d.mainfile=file
            d.decfilename=f'{fname[:-4]}.txt'
            foo=Filee(open(f'{fname[:-4]}.txt','rb'))
            d.decfile=foo
            d.user=request.user
            d.save()
            foo.close()
            os.remove(f'{fname[:-4]}.txt')
            messages.success(request,'FILE DECRYPTED SUCCESSFULLY :) ')
            return redirect('alldec')

        except:
            messages.error(request,'ERROR WHILE DECRYPTING FILE ')
            return render(request,'home.html')
        

@login_required(login_url='login')
def allenc(request):
    if request.method=='GET':

        e=Encfile.objects.filter(user=request.user).order_by('-id')
        context={'enc':e,'flag':1}
        return render(request,'allenc.html',context)

@login_required(login_url='login')
def alldec(request):
    if request.method=='GET':

        d=Decrfile.objects.filter(user=request.user).order_by('-id')
        context={'dec':d,'flag':1}
        return render(request,'alldec.html',context)
    
def downloadenc(request,id):
    e=get_object_or_404(Encfile,id=id)
    response=HttpResponse(e.encfile,content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{e.encfile.name}"'
    return response

def downloaddec(request,id):
    d=get_object_or_404(Decrfile,id=id)
    response=HttpResponse(d.decfile,content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{d.decfile.name}"'
    return response

     




        

             

     
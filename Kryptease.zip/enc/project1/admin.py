from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Encfile)
admin.site.register(Decrfile)
admin.site.register(File)
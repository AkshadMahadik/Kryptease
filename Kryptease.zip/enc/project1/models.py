from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class File(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    filename=models.CharField(max_length=200,null=False,blank=False)
    userfile=models.FileField(blank=False,null=False,upload_to='files/')

    def __str__(self) -> str:
        return self.user.username+str(self.id)

class Encfile(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    mainfile=models.OneToOneField(File,on_delete=models.CASCADE)
    encfilename=models.CharField(max_length=100)
    encfile=models.FileField(upload_to='encfiles/')

    def __str__(self) -> str:
        return self.mainfile.filename

class Decrfile(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)

    mainfile=models.OneToOneField(File,on_delete=models.CASCADE)
    decfilename=models.CharField(max_length=100,default='abc')
    decfile=models.FileField(upload_to='decfiles/')

    def __str__(self) -> str:
        return self.mainfile.filename
    



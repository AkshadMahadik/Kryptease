with open(f'media/thrash/python.enc','wb') as fo:
             fo.write(b'suduwuuwduwdwuduuu')
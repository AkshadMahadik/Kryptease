f=open('/enc/media/thrash/myfile.enc','wb')
f.write(b"loremmmmmmmmmmmmmmmmmmmmmmmm")